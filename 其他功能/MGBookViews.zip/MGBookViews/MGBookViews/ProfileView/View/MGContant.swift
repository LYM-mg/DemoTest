//  MGContant.swift
//  MGBookViews
//  Created by i-Techsys.com on 2017/8/19.
//  Copyright © 2017年 i-Techsys. All rights reserved.
// https://github.com/LYM-mg
// http://www.jianshu.com/u/57b58a39b70e

import UIKit

let MGScreenB: CGRect = UIScreen.main.bounds
let MGScreenS: CGSize = UIScreen.main.bounds.size
let MGScreenW: CGFloat = UIScreen.main.bounds.size.width
let MGScreenH: CGFloat = UIScreen.main.bounds.size.height

let MGHeadViewHeight: CGFloat = 200
let MGTitleHeight: CGFloat = 45


